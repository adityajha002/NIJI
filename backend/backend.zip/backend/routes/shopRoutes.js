const express = require('express');
const db = require('../config/db');
const upload = require('../middleware/upload');
const { uploadImageBuffer } = require('../config/cloudinary');
const verifyToken = require('../middleware/verifyToken');

const router = express.Router();

const uploadShopImage = (req, res, next) => {
      upload.single('image')(req, res, (error) => {
            if (error) {
                  return res.status(400).json({ error: error.message });
            }

            next();
      });
};

const createShop = async (req, res) => {
      const { name, category, pincode, description, latitude, longitude } = req.body;

      try {
            if (!name || !category || !pincode || !description) {
                  return res.status(400).json({ error: 'name, category, pincode and description are required' });
            }

            if (!req.file) {
                  return res.status(400).json({ error: 'Image file is required' });
            }

            let imageUrl;

            try {
                  const uploadResult = await uploadImageBuffer(req.file.buffer);
                  imageUrl = uploadResult.secure_url;
            } catch (error) {
                  console.error('Error uploading shop image:', error);
                  return res.status(502).json({ error: 'Image upload failed. Check Cloudinary credentials.' });
            }

            const result = await db.query(
            'INSERT INTO shops (shopname, category, pincode, description, imageurl, latitude, longitude, userid) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
            [name, category, pincode, description, imageUrl, latitude, longitude, req.user.id]
            );     

      res.json(result.rows[0]);
      } catch (error) {
            console.error('Error creating shop:', error);
            res.status(500).json({ error: 'Internal server error' });
      }
}

router.get('/dashboard', verifyToken, async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM shops WHERE userid = $1', [req.user.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No shop found for this user' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error fetching shop:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', verifyToken, uploadShopImage, createShop);

module.exports = router;
